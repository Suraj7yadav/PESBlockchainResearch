<html>
<head>
<title>DNS Resolver</title>
</head>
<style type="text/css">
	* {
    font-family: sans-serif;
	
	}
	body{
		background: url('server.jpg');
		background-size: cover;

	}
	h2,form{
		text-align: center;
		color: white;

	}
</style>
<body>
<h2>DNS Resolver</h2><br />
<form action="result.php">
	Enter the domain: <input type="text" name="searchName" />
	<br /><br />
	<input type="submit"/>
</form>

</body>
</html>



