package cloudsim.ext.datacenter;

/**
 * @author Bhathiya Wickremasinghe
 */
public enum VirtualMachineState {
	BUSY,
	AVAILABLE
}
